<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" width="{{ $wh }}px"
    height="{{ $wh }}px">
    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
    <g id="SVGRepo_iconCarrier">
        <path
            d="M12 13V7M15 10.0008L9 10M19 10.2C19 14.1764 15.5 17.4 12 21C8.5 17.4 5 14.1764 5 10.2C5 6.22355 8.13401 3 12 3C15.866 3 19 6.22355 19 10.2Z"
            stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
        <path
            d="M12 13V7M15 10.0008L9 10M19 10.2C19 14.1764 15.5 17.4 12 21C8.5 17.4 5 14.1764 5 10.2C5 6.22355 8.13401 3 12 3C15.866 3 19 6.22355 19 10.2Z"
            stroke="#FF900F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-opacity="0.5">
        </path>
    </g>
</svg>