<svg xmlns="http://www.w3.org/2000/svg" width="{{$wh}}" height="{{$wh}}" viewBox="0 0 24 24" fill="none" stroke-width="1.5"
    stroke-linecap="round" stroke-linejoin="round" class="bi bi-person">
    <circle cx="12" cy="12" r="10" stroke="#000000" fill="none"></circle>
    <path d="M15 12a3 3 0 1 0 -6 0a3 3 0 0 0 6 0" fill="#FF900F"></path>
    <path d="M12 15c-2.5 0 -6 1.2 -6 3v1h12v-1c0 -1.8 -3.5 -3 -6 -3z" fill="#000000"></path>
</svg>
